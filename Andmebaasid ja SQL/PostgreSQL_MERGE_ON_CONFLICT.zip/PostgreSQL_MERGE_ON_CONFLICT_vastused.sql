/*PostgreSQL*/

/*�lesanne 3*/

INSERT INTO K�laline_varu (k�lalise_nr, nimi)
SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)
ON CONFLICT DO NOTHING
RETURNING *;

/*�lesanne 4*/

INSERT INTO K�laline_varu AS K (k�lalise_nr, nimi)
SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)
ON CONFLICT (k�lalise_nr) DO UPDATE
SET nimi=EXCLUDED.nimi
WHERE K.k�lalise_nr=EXCLUDED.k�lalise_nr
RETURNING *;

--Alates PostgreSQL 15
MERGE INTO K�laline_varu K
USING (SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)) S
ON (K.k�lalise_nr=S.k�lalise_nr)
WHEN MATCHED THEN
UPDATE SET nimi=S.nimi
WHEN NOT MATCHED THEN INSERT(k�lalise_nr, nimi)
VALUES (S.k�lalise_nr, S.nimi);