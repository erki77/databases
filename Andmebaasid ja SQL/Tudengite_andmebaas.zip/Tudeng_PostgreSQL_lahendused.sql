--�lesanne 1

ALTER TABLE Tudeng ADD COLUMN kommentaar VARCHAR(150);

ALTER TABLE Tudeng DROP COLUMN kommentaar;

--�lesanne 2

UPDATE Tudeng SET kommentaar = Trim( 'Peab varsti l�petama! ' ||  Coalesce(kommentaar,''))
WHERE Extract (Year FROM vastuvotu_aeg)<1995 AND oppesuund LIKE 'LZ%';

UPDATE Tudeng SET kommentaar = Trim( 'Peab varsti l�petama! ' ||  Coalesce(kommentaar,''))
WHERE vastuvotu_aeg<'1995-01-01' AND oppesuund LIKE 'LZ%';

--�lesanne 3

INSERT INTO Aktiivne_oppeaine ( aine_kood, nimetus )
SELECT aine_kood, nimetus
FROM Aine
WHERE EXISTS (SELECT * FROM Oppimine WHERE Oppimine.aine=Aine.aine_kood AND 
oppim_algus>='2000-09-01');

--�lesanne 4

--Vanem �hendamise s�ntaks
SELECT Oppimine.oppimine, Oppimine.tudeng, Tudeng.eesnimi || ' ' || Tudeng.perenimi AS tudengi_nimi, Oppimine.aine, Aine.nimetus AS aine_nimetus, Oppimine.oppejoud, Oppejoud.perenimi AS �ppej�u_perenimi, Oppimine.oppim_algus, Oppimine.oppim_lopp
FROM Aine, Oppejoud, Tudeng, Oppimine
WHERE Tudeng.tudkood = Oppimine.tudeng AND 
Oppejoud.oppejou_kood = Oppimine.oppejoud AND 
Aine.aine_kood = Oppimine.aine
AND Extract (Year FROM oppim_algus)=1998 
AND EXISTS (SELECT * FROM Eksam WHERE Eksam.oppimine=Oppimine.oppimine AND tulemus IN (4,5))
ORDER BY Tudeng.perenimi, Aine.nimetus;

--Uuem �hendamise s�ntaks
SELECT Oppimine.oppimine, Oppimine.tudeng, Tudeng.eesnimi || ' ' || Tudeng.perenimi AS tudengi_nimi, Oppimine.aine, Aine.nimetus AS aine_nimetus, Oppimine.oppejoud, Oppejoud.perenimi AS �ppej�u_perenimi, Oppimine.oppim_algus, Oppimine.oppim_lopp
FROM Aine INNER JOIN Oppimine ON Aine.aine_kood = Oppimine.aine
INNER JOIN Tudeng ON Tudeng.tudkood = Oppimine.tudeng
INNER JOIN Oppejoud ON Oppejoud.oppejou_kood = Oppimine.oppejoud
WHERE Extract (Year FROM oppim_algus)=1998
AND EXISTS (SELECT * FROM Eksam WHERE Eksam.oppimine=Oppimine.oppimine AND tulemus IN (4,5))
ORDER BY Tudeng.perenimi, Aine.nimetus;

--Kuup�ev vahemikuna
SELECT Oppimine.oppimine, Oppimine.tudeng, Tudeng.eesnimi || ' ' || Tudeng.perenimi AS tudengi_nimi, Oppimine.aine, Aine.nimetus AS aine_nimetus, Oppimine.oppejoud, Oppejoud.perenimi AS �ppej�u_perenimi, Oppimine.oppim_algus, Oppimine.oppim_lopp
FROM Aine INNER JOIN Oppimine ON Aine.aine_kood = Oppimine.aine
INNER JOIN Tudeng ON Tudeng.tudkood = Oppimine.tudeng
INNER JOIN Oppejoud ON Oppejoud.oppejou_kood = Oppimine.oppejoud
WHERE oppim_algus>='1998-01-01' AND oppim_algus<'1999-01-01'
AND EXISTS (SELECT * FROM Eksam WHERE Eksam.oppimine=Oppimine.oppimine AND tulemus IN (4,5))
ORDER BY Tudeng.perenimi, Aine.nimetus;

--�lesanne 5

--�hine tabeli avaldis
WITH Yl5_1 AS (SELECT tudkood, Upper(perenimi) AS perenimi, Count(*) AS arv
FROM Eksam INNER JOIN Oppimine ON Eksam.oppimine=Oppimine.oppimine
INNER JOIN Tudeng ON Oppimine.tudeng=Tudeng.tudkood
WHERE tulemus BETWEEN 1 AND 5
GROUP BY tudkood)
SELECT *
FROM Yl5_1
WHERE arv=(SELECT Max(arv) AS maks FROM Yl5_1);

--Lahendus, mis t��tab ka MS Accessis
SELECT tudkood, Upper(perenimi) AS perenimi, Count(*) AS arv
FROM Eksam INNER JOIN Oppimine ON Eksam.oppimine=Oppimine.oppimine
INNER JOIN Tudeng ON Oppimine.tudeng=Tudeng.tudkood
WHERE tulemus BETWEEN 1 AND 5
GROUP BY tudkood
HAVING Count(*)>=ALL(SELECT Count(*) AS arv
FROM Eksam INNER JOIN Oppimine ON Eksam.oppimine=Oppimine.oppimine
WHERE tulemus BETWEEN 1 AND 5
GROUP BY tudeng);

--Sorteerimine ja esimeste valimine
SELECT tudkood, Upper(perenimi) AS perenimi, Count(*) AS arv
FROM Eksam INNER JOIN Oppimine ON Eksam.oppimine=Oppimine.oppimine
INNER JOIN Tudeng ON Oppimine.tudeng=Tudeng.tudkood
WHERE tulemus BETWEEN 1 AND 5
GROUP BY tudkood
ORDER BY arv DESC
FETCH FIRST 1 ROWS WITH TIES;

/*Leian tudengite asetuse pingereas, mis on moodustatud eksamite arvu j�rgi ning valin
pingereas esikohal olijad. Kasutan pingerea moodustamiseks aknafunktsiooni RANK. 
Ka pingerea moodustamine kasutab sorteerimist.*/
WITH Yl5_1 AS (SELECT tudkood, Upper(perenimi) AS perenimi, Count(*) AS arv
FROM Eksam INNER JOIN Oppimine ON Eksam.oppimine=Oppimine.oppimine
INNER JOIN Tudeng ON Oppimine.tudeng=Tudeng.tudkood
WHERE tulemus BETWEEN 1 AND 5
GROUP BY tudkood),
asetused AS (SELECT tudkood, perenimi, arv, RANK() OVER (ORDER BY arv DESC) AS asetus
FROM Yl5_1)
SELECT tudkood, perenimi, arv
FROM asetused
WHERE asetus=1;

--�lesanne 6

DELETE
FROM Tudeng
WHERE tudkood IN
(SELECT Oppimine.tudeng
FROM Oppimine,  Eksam 
WHERE  Oppimine.oppimine = Eksam.oppimine AND Eksam.tulemus=0
GROUP BY Oppimine.tudeng
HAVING Count(Eksam.eksam)>2)
AND tudkood NOT IN
(SELECT tudeng
FROM Oppimine
WHERE NOT EXISTS (SELECT * FROM Eksam WHERE Oppimine.oppimine=Eksam.oppimine));