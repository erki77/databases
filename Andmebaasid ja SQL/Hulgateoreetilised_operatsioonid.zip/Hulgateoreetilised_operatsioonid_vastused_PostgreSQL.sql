/*PostgreSQL*/

/*�lesanne 1*/

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('IDU5661', 'Infos�steemide projekteerimine')
ON CONFLICT DO NOTHING;

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('ITI0206', 'Andmebaasid I')
ON CONFLICT DO NOTHING;

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('ITI0207', 'Andmebaasid II')
ON CONFLICT DO NOTHING;

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('IDU5661', 'Infos�steemide projekteerimine'), ('ITI0206', 'Andmebaasid I'), ('ITI0207', 'Andmebaasid II')
ON CONFLICT DO NOTHING
RETURNING *;

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
SELECT 'IDU5661' AS aine_kood, 'Infos�steemide projekteerimine' AS nimetus
UNION SELECT 'ITI0206' AS aine_kood, 'Andmebaasid I' AS nimetus
UNION SELECT 'ITI0207' AS aine_kood, 'Andmebaasid II' AS nimetus
ON CONFLICT DO NOTHING
RETURNING *;

/*�lesanne 2*/

SELECT aine_kood, nimetus
FROM Aine
UNION SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;

SELECT aine_kood, nimetus
FROM Aine
UNION DISTINCT SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;


SELECT aine_kood, nimetus
FROM Aine
UNION ALL SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;

/*�lesanne 3*/

SELECT Aine.aine_kood, Aine.nimetus
FROM Aine INNER JOIN Aktiivne_oppeaine ON Aine.aine_kood=Aktiivne_oppeaine.aine_kood
AND Aine.nimetus=Aktiivne_oppeaine.nimetus;

SELECT aine_kood, nimetus
FROM Aine
INTERSECT SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;

/*�lesanne 4*/

SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
WHERE NOT EXISTS (SELECT *
FROM Aine
WHERE Aine.aine_kood=Aktiivne_oppeaine.aine_kood
AND Aine.nimetus=Aktiivne_oppeaine.nimetus);

SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
EXCEPT SELECT aine_kood, nimetus
FROM Aine
ORDER BY aine_kood;

SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
WHERE (aine_kood, nimetus) NOT IN (SELECT aine_kood, nimetus
FROM Aine);

SELECT Aktiivne_oppeaine.aine_kood, Aktiivne_oppeaine.nimetus
FROM Aktiivne_oppeaine LEFT JOIN Aine USING (aine_kood, nimetus)
WHERE Aine.aine_kood IS NULL;


/*�lesanne 5*/

SELECT aine_kood, nimetus
FROM Aine
WHERE NOT EXISTS (SELECT *
FROM Aktiivne_oppeaine
WHERE Aine.aine_kood=Aktiivne_oppeaine.aine_kood
AND Aine.nimetus=Aktiivne_oppeaine.nimetus);

SELECT aine_kood, nimetus
FROM Aine
EXCEPT SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;

SELECT aine_kood, nimetus
FROM Aine
WHERE (aine_kood, nimetus) NOT IN (SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine);

SELECT Aine.aine_kood, Aine.nimetus
FROM Aine LEFT JOIN Aktiivne_oppeaine USING (aine_kood, nimetus)
WHERE Aktiivne_oppeaine.aine_kood IS NULL;

/*�lesanne 6*/

SELECT Aine.aine_kood, Aine.nimetus, Count(*) AS arv
FROM Aine INNER JOIN Oppimine ON Aine.aine_kood=Oppimine.aine
GROUP BY Aine.aine_kood, Aine.nimetus
UNION SELECT Aine.aine_kood, Aine.nimetus, 0 AS arv
FROM Aine
WHERE NOT EXISTS (SELECT *
FROM Oppimine
WHERE Aine.aine_kood=Oppimine.aine)
ORDER BY arv DESC, aine_kood;