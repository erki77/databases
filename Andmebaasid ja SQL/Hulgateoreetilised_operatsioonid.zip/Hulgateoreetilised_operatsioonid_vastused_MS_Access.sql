/*MS Access*/

/*�lesanne 1*/

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('IDU5661', 'Infos�steemide projekteerimine');

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('ITI0206', 'Andmebaasid I');

INSERT INTO Aktiivne_oppeaine (aine_kood, nimetus)
VALUES ('ITI0207', 'Andmebaasid II');

/*�lesanne 2*/

SELECT aine_kood, nimetus
FROM Aine
UNION SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;

SELECT aine_kood, nimetus
FROM Aine
UNION ALL SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
ORDER BY aine_kood;

/*�lesanne 3*/

SELECT Aine.aine_kood, Aine.nimetus
FROM Aine INNER JOIN Aktiivne_oppeaine ON Aine.aine_kood=Aktiivne_oppeaine.aine_kood
AND Aine.nimetus=Aktiivne_oppeaine.nimetus;

/*�lesanne 4*/

SELECT aine_kood, nimetus
FROM Aktiivne_oppeaine
WHERE NOT EXISTS (SELECT *
FROM Aine
WHERE Aine.aine_kood=Aktiivne_oppeaine.aine_kood
AND Aine.nimetus=Aktiivne_oppeaine.nimetus);

SELECT Aktiivne_oppeaine.aine_kood, Aktiivne_oppeaine.nimetus
FROM Aktiivne_oppeaine LEFT JOIN Aine ON (Aktiivne_oppeaine.nimetus = Aine.nimetus) AND (Aktiivne_oppeaine.aine_kood = Aine.aine_kood)
WHERE Aine.aine_kood IS NULL;

/*�lesanne 5*/

SELECT aine_kood, nimetus
FROM Aine
WHERE NOT EXISTS (SELECT *
FROM Aktiivne_oppeaine
WHERE Aine.aine_kood=Aktiivne_oppeaine.aine_kood
AND Aine.nimetus=Aktiivne_oppeaine.nimetus);

SELECT Aine.aine_kood, Aine.nimetus
FROM Aine LEFT JOIN Aktiivne_oppeaine ON (Aktiivne_oppeaine.nimetus = Aine.nimetus) AND (Aktiivne_oppeaine.aine_kood = Aine.aine_kood)
WHERE Aktiivne_oppeaine.aine_kood IS NULL;


/*�lesanne 6*/

SELECT Aine.aine_kood, Aine.nimetus, Count(*) AS arv
FROM Aine INNER JOIN Oppimine ON Aine.aine_kood=Oppimine.aine
GROUP BY Aine.aine_kood, Aine.nimetus
UNION SELECT Aine.aine_kood, Aine.nimetus, 0 AS arv
FROM Aine
WHERE NOT EXISTS (SELECT *
FROM Oppimine
WHERE Aine.aine_kood=Oppimine.aine)
ORDER BY arv DESC, aine_kood;