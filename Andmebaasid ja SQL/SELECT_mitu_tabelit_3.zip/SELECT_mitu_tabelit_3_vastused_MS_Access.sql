/*MS Access*/

/*�lesanne 1*/

SELECT Round(reserveerimisteta.arv/iif(kokku.arv=0,NULL, kokku.arv)*100,1) AS protsent
FROM (SELECT Count(*) AS arv
FROM K�laline
WHERE k�lalise_nr NOT IN (SELECT k�lalise_nr
FROM Reserveerimine)) AS reserveerimisteta,
(SELECT Count(*) AS arv
FROM K�laline) AS kokku;

--PostgreSQL'i Count+FILTER lahendusele vastav lahendus
SELECT 
Round(Count(iif(NOT EXISTS (SELECT * FROM Reserveerimine
WHERE K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr),1,NULL))/iif(Count(*)=0,NULL, Count(*))*100,1) AS protsent
FROM K�laline;

/*�lesanne 2*/

SELECT nimi AS hotelli_nimi, Hotell.hotelli_nr, Ruum.ruumi_nr
FROM Hotell INNER JOIN Ruum ON Hotell.hotelli_nr=Ruum.hotelli_nr
WHERE linn='Tallinn' 
AND ruumi_t��p='Luksusnumber'
AND Hotell.hotelli_nr & '_' & Ruum.ruumi_nr IN (SELECT hotelli_nr & '_' & ruumi_nr
FROM Reserveerimine
WHERE k�lalise_nr IN
(SELECT K�laline.k�lalise_nr
FROM K�laline LEFT JOIN Reserveerimine ON K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr
GROUP BY K�laline.k�lalise_nr
HAVING Count(Reserveerimine.k�lalise_nr)<
(SELECT Avg(arv) AS keskmine
FROM (SELECT Count(Reserveerimine.k�lalise_nr) AS arv
FROM K�laline LEFT JOIN Reserveerimine ON K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr
GROUP BY K�laline.k�lalise_nr) AS res_arv)))
ORDER BY Hotell.hotelli_nr, Ruum.ruumi_nr;

/*�lesanne 3*/

SELECT *
FROM Ruum 
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
AND NOT EXISTS (SELECT *
FROM Reserveerimine
WHERE #2004-01-01# BETWEEN alguse_aeg AND lopu_aeg
AND Reserveerimine.hotelli_nr=Ruum.hotelli_nr
AND Reserveerimine.ruumi_nr=Ruum.ruumi_nr)
ORDER BY ruumi_nr;
