/*PostgreSQL*/

/*�lesanne 1*/

/*Miks on t��biteisendus vajalik?
https://stackoverflow.com/questions/34504497/division-not-giving-my-answer-in-postgresql
*/

SELECT Round(reserveerimisteta.arv/Nullif(kokku.arv,0)*100,1) AS protsent
FROM (SELECT Count(*)::decimal AS arv
FROM K�laline
WHERE k�lalise_nr NOT IN (SELECT k�lalise_nr
FROM Reserveerimine)) AS reserveerimisteta,
(SELECT Count(*)::decimal AS arv
FROM K�laline) AS kokku;

--Nullif asemel CASE
SELECT Round(reserveerimisteta.arv/CASE WHEN kokku.arv=0 THEN NULL ELSE kokku.arv END*100,1) AS protsent
FROM (SELECT Count(*)::decimal AS arv
FROM K�laline
WHERE k�lalise_nr NOT IN (SELECT k�lalise_nr
FROM Reserveerimine)) AS reserveerimisteta,
(SELECT Count(*)::decimal AS arv
FROM K�laline) AS kokku;

--T��biteisndus kasutades Cast'i
SELECT Round(reserveerimisteta.arv/Nullif(kokku.arv,0)*100,1) AS protsent
FROM (SELECT Cast(Count(*) AS decimal) AS arv
FROM K�laline
WHERE k�lalise_nr NOT IN (SELECT k�lalise_nr
FROM Reserveerimine)) AS reserveerimisteta,
(SELECT Cast(Count(*) AS decimal) AS arv
FROM K�laline) AS kokku;

--Alamp�ringud �histe tabeli avaldistena
WITH kokku AS (SELECT Count(*)::decimal AS arv
FROM K�laline),
reserveerimata AS (SELECT Count(*)::decimal AS arv
FROM K�laline
WHERE NOT EXISTS (SELECT k�lalise_nr
FROM Reserveerimine
WHERE Reserveerimine.k�lalise_nr=K�laline.k�lalise_nr))
SELECT Round(reserveerimata.arv/Nullif(kokku.arv,0)*100,1) AS protsent
FROM kokku, reserveerimata;

--Count + FILTER
SELECT 
Round(Count(*) FILTER (WHERE NOT EXISTS (SELECT * FROM Reserveerimine WHERE K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr))::decimal/Nullif(Count(*)::decimal,0)*100,1) AS protsent
FROM K�laline

/*�lesanne 2*/

SELECT nimi AS hotelli_nimi, Hotell.hotelli_nr, Ruum.ruumi_nr
FROM Hotell INNER JOIN Ruum ON Hotell.hotelli_nr=Ruum.hotelli_nr
WHERE linn='Tallinn' 
AND ruumi_t��p='Luksusnumber'
AND (Hotell.hotelli_nr, Ruum.ruumi_nr) IN (SELECT hotelli_nr, ruumi_nr
FROM Reserveerimine
WHERE k�lalise_nr IN
(SELECT K�laline.k�lalise_nr
FROM K�laline LEFT JOIN Reserveerimine ON K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr
GROUP BY K�laline.k�lalise_nr
HAVING Count(Reserveerimine.k�lalise_nr)<
(SELECT Avg(arv) AS keskmine
FROM (SELECT Count(Reserveerimine.k�lalise_nr) AS arv
FROM K�laline LEFT JOIN Reserveerimine ON K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr
GROUP BY K�laline.k�lalise_nr) AS res_arv)))
ORDER BY Hotell.hotelli_nr, Ruum.ruumi_nr;

--�hendamine kasutades USING s�ntaksi
SELECT nimi AS hotelli_nimi, Hotell.hotelli_nr, Ruum.ruumi_nr
FROM Hotell INNER JOIN Ruum USING (hotelli_nr)
WHERE linn='Tallinn' 
AND ruumi_t��p='Luksusnumber'
AND (Hotell.hotelli_nr, Ruum.ruumi_nr) IN (SELECT hotelli_nr, ruumi_nr
FROM Reserveerimine
WHERE k�lalise_nr IN
(SELECT K�laline.k�lalise_nr
FROM K�laline LEFT JOIN Reserveerimine USING (k�lalise_nr)
GROUP BY K�laline.k�lalise_nr
HAVING Count(Reserveerimine.k�lalise_nr)<
(SELECT Avg(arv) AS keskmine
FROM (SELECT Count(Reserveerimine.k�lalise_nr) AS arv
FROM K�laline LEFT JOIN Reserveerimine USING (k�lalise_nr)
GROUP BY K�laline.k�lalise_nr) AS res_arv)))
ORDER BY Hotell.hotelli_nr, Ruum.ruumi_nr;

/*�lesanne 3*/

SELECT *
FROM Ruum 
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
AND NOT EXISTS (SELECT *
FROM Reserveerimine
WHERE '2004-01-01' BETWEEN alguse_aeg AND lopu_aeg
AND Reserveerimine.hotelli_nr=Ruum.hotelli_nr
AND Reserveerimine.ruumi_nr=Ruum.ruumi_nr)
ORDER BY ruumi_nr;
