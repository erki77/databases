/*PostgreSQL*/

/*�lesanne 1*/

SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS k�lalise_nimi
FROM K�laline
WHERE k�lalise_nr NOT IN (
SELECT k�lalise_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru'))
ORDER BY perenimi, k�lalise_nr;

/*�lesanne 2*/

SELECT Round(Avg(lopu_aeg-alguse_aeg),1) AS keskm_pikkus,
Min(lopu_aeg-alguse_aeg) AS min_pikkus,
Max(lopu_aeg-alguse_aeg) AS max_pikkus
FROM Hotell AS H, Reserveerimine AS R
WHERE linn='Tallinn'
AND H.hotelli_nr=R.hotelli_nr
AND lopu_aeg-alguse_aeg>2;

/*�lesanne 3*/

SELECT Extract(Year FROM alguse_aeg) AS aasta, Count(*) AS arv
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
GROUP BY Extract(Year FROM alguse_aeg)
HAVING Count(*)>=ALL(SELECT Count(*) AS arv
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
GROUP BY Extract(Year FROM alguse_aeg));

--�hise tabeli avaldisega

WITH res_arv AS (SELECT Extract(Year FROM alguse_aeg) AS aasta, Count(*) AS arv
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
GROUP BY aasta)
SELECT aasta, arv
FROM res_arv
WHERE arv=(SELECT Max(arv) AS maks FROM res_arv);

--Asetuse arvutamisega kasutades aknafunktsiooni RANK

WITH asetused AS (SELECT Extract(Year FROM alguse_aeg) AS aasta, Count(*) AS arv, RANK() OVER (ORDER BY Count(*)DESC) AS asetus 
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
GROUP BY aasta)
SELECT aasta, arv
FROM asetused
WHERE asetus=1;

--Kasutades sorteerimist - MS Accessi TOP analoog

SELECT Extract(Year FROM alguse_aeg) AS aasta, Count(*) AS arv
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE nimi='Viru')
GROUP BY aasta
ORDER BY arv DESC
FETCH FIRST 1 ROWS WITH TIES;

/*�lesanne 4*/

SELECT K�laline.k�lalise_nr, Trim(eesnimi  || ' ' || Coalesce(perenimi,'')) AS k�lalise_nimi, Count(*) AS arv
FROM K�laline INNER JOIN Reserveerimine ON K�laline.k�lalise_nr=Reserveerimine.k�lalise_nr
GROUP BY K�laline.k�lalise_nr, Trim(eesnimi  || ' ' || Coalesce(perenimi,''))
HAVING Count(*)> (SELECT Avg(arv) AS keskmine
FROM (SELECT Count(*) AS arv
FROM Reserveerimine
GROUP BY k�lalise_nr) AS ap)
ORDER BY K�laline.k�lalise_nr;

/*�lesanne 5*/

SELECT *
FROM (SELECT K.k�lalise_nr, perenimi, Extract(Month FROM alguse_aeg) AS alguse_kuu, Count(*) AS arv
FROM K�laline AS K, Reserveerimine AS R
WHERE K.k�lalise_nr=R.k�lalise_nr
GROUP BY K.k�lalise_nr, perenimi, Extract(Month FROM alguse_aeg)) AS Rk
WHERE arv=(SELECT Max(arv) AS maks 
FROM (SELECT k�lalise_nr, Extract(Month FROM alguse_aeg) AS alguse_kuu, Count(*) AS arv
FROM Reserveerimine
GROUP BY k�lalise_nr, Extract(Month FROM alguse_aeg)) AS Res_kuus WHERE Rk.k�lalise_nr=Res_kuus.k�lalise_nr);

--�hise tabeli avaldisega

WITH res_kuus AS (SELECT K.k�lalise_nr, perenimi, Extract(Month FROM alguse_aeg) AS alguse_kuu, Count(*) AS arv
FROM K�laline AS K, Reserveerimine AS R
WHERE K.k�lalise_nr=R.k�lalise_nr
GROUP BY K.k�lalise_nr, perenimi, Extract( Month FROM alguse_aeg))
SELECT *
FROM Res_kuus AS Rk
WHERE arv=(SELECT Max(arv) AS maks FROM Res_kuus WHERE Rk.k�lalise_nr=Res_kuus.k�lalise_nr);

--K�laliste kaupa asetuse arvutamisega kasutades aknafunktsiooni RANK koos sektsioonideks jagamisega

WITH asetused AS (SELECT K.k�lalise_nr, perenimi, Extract(Month FROM alguse_aeg) AS alguse_kuu, Count(*) AS arv,
RANK() OVER (PARTITION BY K.k�lalise_nr ORDER BY Count(*) DESC) AS asetus
FROM K�laline AS K, Reserveerimine AS R
WHERE K.k�lalise_nr=R.k�lalise_nr
GROUP BY K.k�lalise_nr, perenimi, Extract( Month FROM alguse_aeg))
SELECT *
FROM asetused
WHERE asetus=1;