CREATE TABLE Kaup (
	kauba_kood VARCHAR ( 15 ) NOT NULL,
	nimetus VARCHAR ( 100 ) NOT NULL,
	hetke_hind DECIMAL ( 19, 4 ) NOT NULL,
	pakendi_tyyp_kood SMALLINT NOT NULL,
	kauba_seisundi_liik_kood SMALLINT DEFAULT 1 NOT NULL,
	kirjeldus MEMO,
	CONSTRAINT PK_Kaup PRIMARY KEY (kauba_kood)
	);
CREATE INDEX idxfk_Kaup_Kauba_seisundi_liik ON Kaup (kauba_seisundi_liik_kood );
CREATE INDEX idxfk_Kaup_Pakendi_tyyp ON Kaup (pakendi_tyyp_kood );
CREATE TABLE Pakendi_tyyp (
	pakendi_tyyp_kood SMALLINT NOT NULL,
	nimetus VARCHAR ( 50 ) NOT NULL,
	kirjeldus VARCHAR ( 255 ),
	CONSTRAINT PK_Pakendi_tyyp PRIMARY KEY (pakendi_tyyp_kood),
	CONSTRAINT AK_Pakendi_tyyp_nimetus UNIQUE (nimetus)
	);
CREATE TABLE Kauba_seisundi_liik (
	kauba_seisundi_liik_kood SMALLINT NOT NULL,
	nimetus VARCHAR ( 50 ) NOT NULL,
	kirjeldus VARCHAR ( 255 ),
	CONSTRAINT AK_Kauba_seisundi_liik_nimetus UNIQUE (nimetus),
	CONSTRAINT PK_Kauba_seisundi_liik PRIMARY KEY (kauba_seisundi_liik_kood)
	);
ALTER TABLE Kaup ADD CONSTRAINT FK_Kaup_Pakendi_tyyp FOREIGN KEY (pakendi_tyyp_kood) REFERENCES Pakendi_tyyp (pakendi_tyyp_kood)  ON DELETE NO ACTION ON UPDATE CASCADE;
ALTER TABLE Kaup ADD CONSTRAINT FK_Kaup_Kauba_seisundi_liik FOREIGN KEY (kauba_seisundi_liik_kood) REFERENCES Kauba_seisundi_liik (kauba_seisundi_liik_kood)  ON DELETE NO ACTION ON UPDATE CASCADE;