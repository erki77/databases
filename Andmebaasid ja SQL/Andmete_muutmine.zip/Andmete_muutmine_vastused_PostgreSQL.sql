/*PostgreSQL*/

/*�lesanne 1*/

DROP TABLE Reserveerimine_koopia;

SELECT * INTO Reserveerimine_koopia
FROM Reserveerimine;

DELETE FROM Reserveerimine
WHERE Extract(Year FROM alguse_aeg) NOT IN (2012, 2015)
AND lopu_aeg-alguse_aeg>(SELECT Avg(lopu_aeg-alguse_aeg)+1 AS kesk
FROM Reserveerimine_koopia)
RETURNING *;

DROP TABLE Reserveerimine_koopia;

SELECT * INTO Reserveerimine_koopia
FROM Reserveerimine;

UPDATE Reserveerimine SET lopu_aeg=NULL, on_aktuaalne=FALSE
WHERE Extract(Year FROM alguse_aeg) NOT IN (2012, 2015)
AND lopu_aeg-alguse_aeg>(SELECT Avg(lopu_aeg-alguse_aeg)+1 AS kesk
FROM Reserveerimine_koopia)
RETURNING *;

/*�lesanne 2*/

INSERT INTO K�laline_varu (k�lalise_nr, nimi)
SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)
AND k�lalise_nr NOT IN (SELECT k�lalise_nr
FROM K�laline_varu)
RETURNING *;

/*�lesanne 3*/

INSERT INTO K�laline_varu (k�lalise_nr, nimi)
SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)
ON CONFLICT DO NOTHING
RETURNING *;

/*�lesanne 4*/

INSERT INTO K�laline_varu AS K (k�lalise_nr, nimi)
SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)
ON CONFLICT (k�lalise_nr) DO UPDATE
SET nimi=EXCLUDED.nimi
WHERE K.k�lalise_nr=EXCLUDED.k�lalise_nr
RETURNING *;

--Alates PostgreSQL 15
MERGE INTO K�laline_varu K
USING (SELECT k�lalise_nr, Trim(eesnimi || ' ' || Coalesce(perenimi,'')) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)) S
ON (K.k�lalise_nr=S.k�lalise_nr)
WHEN MATCHED THEN
UPDATE SET nimi=S.nimi
WHEN NOT MATCHED THEN INSERT(k�lalise_nr, nimi)
VALUES (S.k�lalise_nr, S.nimi);