/*MS Access*/

/*�lesanne 1*/

DROP TABLE Reserveerimine_koopia;

SELECT * INTO Reserveerimine_koopia
FROM Reserveerimine;

DELETE FROM Reserveerimine
WHERE Year(alguse_aeg) NOT IN (2012, 2015)
AND lopu_aeg-alguse_aeg>(SELECT Avg(lopu_aeg-alguse_aeg)+1 AS kesk
FROM Reserveerimine_koopia);

SELECT * INTO Reserveerimine_koopia
FROM Reserveerimine;

UPDATE Reserveerimine SET lopu_aeg=NULL, on_aktuaalne=FALSE
WHERE Year(alguse_aeg) NOT IN (2012, 2015)
AND lopu_aeg-alguse_aeg>(SELECT Avg(lopu_aeg-alguse_aeg)+1 AS kesk
FROM Reserveerimine_koopia);

/*�lesanne 1*/

INSERT INTO K�laline_varu (k�lalise_nr, nimi)
SELECT k�lalise_nr, Trim(eesnimi & ' ' & perenimi) AS nimi
FROM K�laline
WHERE k�lalise_nr IN
(SELECT k�lalise_nr
FROM (SELECT DISTINCT k�lalise_nr, hotelli_nr
FROM Reserveerimine
WHERE hotelli_nr IN (SELECT hotelli_nr
FROM Hotell
WHERE linn='Tallinn')) AS ap
GROUP BY k�lalise_nr
HAVING Count(*)=1)
AND k�lalise_nr NOT IN (SELECT k�lalise_nr
FROM K�laline_varu);