/*PostgreSQL*/

/*�lesanne 1*/

--a
SELECT aine_kood, Upper(nimetus) AS nimetus, kommentaar, punkte
FROM Aine
WHERE (aine_kood LIKE 'F%' OR aine_kood LIKE 'H%')
AND aine_kood NOT LIKE '%2'
AND kommentaar IS NOT NULL
AND ((punkte>=1 AND punkte<=2) OR punkte>3)
ORDER BY punkte, nimetus DESC;

--Regulaaravaldisega
SELECT aine_kood, Upper(nimetus) AS nimetus, kommentaar, punkte
FROM Aine
WHERE aine_kood ~* '^[FH].*[^2]$'
AND kommentaar IS NOT NULL
AND (punkte BETWEEN 1 AND 2 OR punkte>3)
ORDER BY punkte, nimetus DESC;

/*�lesanne 2*/

--a
SELECT Count(*) AS arv, Round(Avg(punkte),1) AS keskmine
FROM Aine
WHERE (aine_kood LIKE 'F%' OR aine_kood LIKE 'H%')
AND aine_kood NOT LIKE '%2'
AND kommentaar IS NOT NULL
AND ((punkte>=1 AND punkte<=2) OR punkte>3);

--�hise tabeli avaldisega
WITH Yl1 AS (SELECT aine_kood, punkte
FROM Aine
WHERE (aine_kood LIKE 'F%' OR aine_kood LIKE 'H%')
AND aine_kood NOT LIKE '%2'
AND kommentaar IS NOT NULL
AND ((punkte>=1 AND punkte<=2) OR punkte>3))
SELECT Count(*) AS arv, Round(Avg(punkte),1) AS keskmine
FROM Yl1;

--Andmebaasis loodud vaate e virtuaalse tabeliga
CREATE OR REPLACE VIEW Yl1 AS 
SELECT aine_kood, Upper(nimetus) AS nimetus, kommentaar, punkte
FROM Aine
WHERE (aine_kood LIKE 'F%' OR aine_kood LIKE 'H%')
AND aine_kood NOT LIKE '%2'
AND kommentaar IS NOT NULL
AND ((punkte>=1 AND punkte<=2) OR punkte>3);

SELECT Count(*) AS arv, Round(Avg(punkte),1) AS keskmine
FROM Yl1;