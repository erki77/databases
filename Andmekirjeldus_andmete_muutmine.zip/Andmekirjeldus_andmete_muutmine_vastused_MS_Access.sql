/*MS Access*/

/*�lesanne 1*/

DELETE FROM K�laline_koopia;

ALTER TABLE K�laline_koopia ADD CONSTRAINT pk_k�laline_koopia PRIMARY KEY (k�lalise_nr);

ALTER TABLE K�laline_koopia ALTER COLUMN eesnimi VARCHAR(50) NOT NULL;

ALTER TABLE K�laline_koopia ALTER COLUMN aadress SET DEFAULT "Eesti";

INSERT INTO K�laline_koopia (k�lalise_nr, eesnimi, perenimi)
SELECT k�lalise_nr, eesnimi, perenimi
FROM K�laline
WHERE k�lalise_nr NOT IN
(SELECT k�lalise_nr
FROM (Reserveerimine INNER JOIN Ruum ON Reserveerimine.ruumi_nr=Ruum.ruumi_nr 
AND Reserveerimine.hotelli_nr=Ruum.hotelli_nr) INNER JOIN Hotell ON Ruum.hotelli_nr=Hotell.hotelli_nr
WHERE Ruum.ruumi_t��p='Luksusnumber'
AND Hotell.linn='Tallinn');