-- Exported from MS Access to PostgreSQL
-- (C) 1997-98 CYNERGI - www.cynergi.net, info@cynergi.net

SET client_encoding=LATIN9;

/*Either everything succeeds or all fails*/
START TRANSACTION;

CREATE TABLE Guest (
guest_nr  SERIAL,
given_name VARCHAR(50),
surname VARCHAR(50) NOT NULL,
address VARCHAR(255),
CONSTRAINT pk_guest PRIMARY KEY (guest_nr));

CREATE TABLE Guest_backup (
guest_nr INTEGER NOT NULL,
guest_name VARCHAR(150),
address VARCHAR(255),
number_of_visits INTEGER, 
CONSTRAINT pk_guest_backup PRIMARY KEY (guest_nr),
CONSTRAINT chk_guest_backup_number_of_visits CHECK ( number_of_visits >=0 ));

CREATE TABLE Hotel (
hotel_nr  SERIAL,
hotel_name VARCHAR(50) NOT NULL,
city VARCHAR(50) NOT NULL,
CONSTRAINT pk_hotel PRIMARY KEY (hotel_nr),
CONSTRAINT ak_hotel_hotel_name UNIQUE (hotel_name));

CREATE TABLE Room (
room_nr INTEGER NOT NULL,
hotel_nr INTEGER NOT NULL,
room_type VARCHAR(50) NOT NULL,
price DECIMAL(10,2) NOT NULL DEFAULT 50,
CONSTRAINT pk_room PRIMARY KEY (room_nr, hotel_nr),
CONSTRAINT chk_room_price CHECK (price>0));

CREATE TABLE Room_backup (
room_nr INTEGER NOT NULL,
hotel_nr INTEGER NOT NULL,
room_type VARCHAR(50) NOT NULL,
price DECIMAL(10,2) NOT NULL DEFAULT 50, 
CONSTRAINT pk_room_backup PRIMARY KEY (room_nr, hotel_nr),
CONSTRAINT chk_room_backup_price CHECK (price>0));

CREATE TABLE Reservation (
hotel_nr INTEGER NOT NULL,
room_nr INTEGER NOT NULL,
guest_nr INTEGER NOT NULL,
beginning_date TIMESTAMP NOT NULL,
end_date DATE,
is_active BOOLEAN NOT NULL DEFAULT TRUE,
comment TEXT,
CONSTRAINT pk_reservation PRIMARY KEY (hotel_nr, guest_nr, beginning_date, room_nr));

ALTER TABLE Room_backup ADD CONSTRAINT fk_Room_backup_hotel_nr FOREIGN KEY (hotel_nr) REFERENCES Hotel(hotel_nr) ON UPDATE CASCADE ON DELETE CASCADE;
CREATE INDEX idx_Room_backup_hotel_nr ON Room_backup(hotel_nr);

ALTER TABLE Reservation ADD CONSTRAINT fk_Reservation_guest_nr FOREIGN KEY (guest_nr) REFERENCES Guest(guest_nr) ON UPDATE CASCADE;
CREATE INDEX idx_Reservation_guest_nr ON Reservation(guest_nr);

ALTER TABLE Room ADD CONSTRAINT fk_Room_hotel_nr FOREIGN KEY (hotel_nr) REFERENCES Hotel(hotel_nr) ON UPDATE CASCADE ON DELETE CASCADE;
CREATE INDEX idx_Room_hotel_nr ON Room(hotel_nr);

ALTER TABLE Reservation ADD CONSTRAINT fk_Reservation_room_nr FOREIGN KEY (room_nr, hotel_nr) REFERENCES Room(room_nr, hotel_nr)  ON UPDATE CASCADE;
CREATE INDEX idx_Reservation_room_nr ON Reservation(room_nr);

ALTER TABLE Reservation ADD CONSTRAINT fk_Reservation_hotel_nr FOREIGN KEY (hotel_nr) REFERENCES Hotel(hotel_nr)  ON UPDATE CASCADE;
CREATE INDEX idx_Reservation_hotel_nr ON Reservation(hotel_nr);

INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (1, 'Aare', 'Vooster', 'Tallinn, Tihase 2');
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (2, 'Ants', 'Tali', 'Tartu, R�ni 2');
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (3, 'Eric', 'Swensson', NULL);
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (4, 'Thomas', 'Shark', NULL);
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (5, 'Kati', 'Karu', 'Tallinn, Ristiku 22-3');
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (6, 'Teet', 'Tee', 'Tallinn, Sipelga 15-5');
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (7, 'Johhn', 'Smith', NULL);
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (9, 'Eric', 'Smith', NULL);
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (10, NULL, 'Smith', 'London');
INSERT INTO Guest (guest_nr, given_name, surname, address)
VALUES (12, 'Erki', 'Eessaar', 'Tallinn');

/*The next value outputed by the sequence generator will be 13*/
SELECT setval('guest_guest_nr_seq', 12);

INSERT INTO Hotel (hotel_nr, hotel_name, city)
VALUES (1, 'Viru', 'Tallinn');
INSERT INTO Hotel (hotel_nr, hotel_name, city)
VALUES (2, 'Ol�mpia', 'Tallinn');
INSERT INTO Hotel (hotel_nr, hotel_name, city)
VALUES (3, 'Palace', 'Tartu');
INSERT INTO Hotel (hotel_nr, hotel_name, city)
VALUES (8, 'Radison', 'Tallinn');
INSERT INTO Hotel (hotel_nr, hotel_name, city)
VALUES (10, 'Star', 'Tallinn');

/*The next value outputed by the sequence generator will be 11*/
SELECT setval('hotel_hotel_nr_seq', 10);

INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (0, 1, 'Luxurious suite', 500);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (1, 1, 'Business suite', 110.5);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (1, 2, 'Luxurious suite', 210);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (1, 3, 'Luxurious suite', 538.5689);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (2, 1, 'Business suite', 110.5);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (2, 2, 'Luxurious suite', 262);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (2, 3, 'Luxurious suite', 502.3979);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (3, 1, 'Business suite', 121.75);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (3, 2, 'Luxurious suite', 283);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (3, 3, 'Luxurious suite', 502.3979);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (4, 1, 'Business suite', 132);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (4, 2, 'Business suite', 157);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (4, 3, 'Luxurious suite', 466.2264);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (5, 1, 'Business suite', 99.25);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (5, 2, 'Business suite', 126);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (6, 1, 'Business suite', 100);
INSERT INTO Room (room_nr, hotel_nr, room_type, price)
VALUES (6, 2, 'Luxurious suite', 150);

INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 4, 1, '2010-02-18 00:00:00', '2010-02-23 00:00:00', 'f', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 5, 1, '2014-04-15 00:00:00', '2014-04-16 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 0, 1, '2014-04-16 00:00:00', '2014-04-18 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 1, 1, '2014-04-16 00:00:00', '2014-04-19 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 3, 1, '2016-03-19 00:00:00', '2016-03-21 00:00:00', 'f', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 2, 1, '2018-01-10 00:00:00', '2018-01-11 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 3, 1, '2018-03-06 00:00:00', '2018-03-07 00:00:00', 'f', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 4, 2, '2004-03-27 00:00:00', '2004-05-01 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 2, 2, '2010-01-01 00:00:00', '2010-01-05 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 2, 3, '2009-03-01 00:00:00', '2009-03-28 00:00:00', 'f', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 0, 3, '2010-03-12 00:00:00', '2010-03-13 00:00:00', 't', 'Wishes peace and quiet');
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 2, 3, '2014-03-27 00:00:00', '2014-03-28 00:00:00', 't', 'Very important');
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 4, 4, '2005-02-18 00:00:00', '2005-04-21 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 4, 4, '2009-03-10 00:00:00', '2009-04-12 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 5, 7, '2011-03-12 00:00:00', '2011-03-20 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 0, 9, '2011-03-08 00:00:00', '2011-03-12 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (1, 3, 9, '2018-03-10 00:00:00', '2018-03-12 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 1, 1, '2011-03-08 00:00:00', '2011-03-14 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 5, 1, '2011-03-08 00:00:00', '2011-03-09 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 3, 1, '2015-03-11 00:00:00', '2015-03-15 00:00:00', 'f', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 2, 1, '2017-02-14 00:00:00', '2017-02-15 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 3, 2, '2003-02-01 00:00:00', '2003-02-02 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 1, 2, '2003-03-01 00:00:00', '2003-03-03 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 2, 2, '2011-03-08 00:00:00', '2011-03-11 00:00:00', 't', 'Wishes peace and quiet');
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 1, 3, '2004-03-09 00:00:00', '2004-03-11 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 1, 3, '2006-08-01 00:00:00', '2006-08-05 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 2, 3, '2014-03-29 00:00:00', '2014-03-30 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 1, 3, '2018-03-03 00:00:00', '2018-03-05 00:00:00', 't', 'Wants to sleep long');
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 2, 4, '2004-01-01 00:00:00', '2004-01-21 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 4, 7, '2002-08-18 00:00:00', '2002-08-21 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 3, 7, '2003-12-22 00:00:00', '2003-12-28 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (2, 4, 7, '2004-03-10 00:00:00', '2004-03-15 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 1, '2009-01-03 00:00:00', NULL, 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 3, 1, '2014-03-27 00:00:00', '2014-03-30 00:00:00', 'f', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 1, '2017-02-18 00:00:00', '2017-02-19 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 4, 2, '2005-02-18 00:00:00', '2005-02-25 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 4, 2, '2011-03-17 00:00:00', '2011-03-19 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 4, 2, '2017-02-14 00:00:00', '2017-02-16 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 3, '2010-03-01 00:00:00', '2010-03-02 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 3, '2017-02-14 00:00:00', '2017-02-16 00:00:00', 't', 'Wants flowers for greeting');
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 4, 6, '2003-03-10 00:00:00', '2003-03-15 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 4, 7, '2018-03-10 00:00:00', NULL, 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 9, '2002-05-11 00:00:00', '2002-05-22 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 3, 9, '2010-02-23 00:00:00', '2010-03-01 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 9, '2015-03-18 00:00:00', '2015-03-20 00:00:00', 't', NULL);
INSERT INTO Reservation (hotel_nr, room_nr, guest_nr, beginning_date, end_date, is_active, comment)
VALUES (3, 2, 9, '2016-03-20 00:00:00', '2016-03-22 00:00:00', 't', NULL);

COMMIT;
